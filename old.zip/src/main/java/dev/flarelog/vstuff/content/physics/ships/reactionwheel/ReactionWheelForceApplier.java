package dev.flarelog.vstuff.content.physics.ships.reactionwheel;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import org.joml.Vector3d;
import org.valkyrienskies.core.impl.game.ships.PhysShipImpl;


import net.minecraft.core.BlockPos;
import dev.flarelog.vstuff.infrastructure.config.VStuffConfigs;

@JsonAutoDetect(
        fieldVisibility = JsonAutoDetect.Visibility.ANY
)
public class ReactionWheelForceApplier {
    private final ReactionWheelData data;

    public ReactionWheelForceApplier(ReactionWheelData data) {
        this.data = data;
    }


    public void applyForces(BlockPos pos, PhysShipImpl ship) {
        if (data.rotationSpeed == 0 || data.facing == null) return;

        if (data.mode == ReactionWheelData.ReactionWheelMode.DIRECT) {
            applyDirectTorque(ship);
        } else {
            applyStabilizationTorque(ship);
        }
    }

    private void applyDirectTorque(PhysShipImpl ship) {

        double maxSpeed = VStuffConfigs.server().reactionWheelMaxSpeed.get();
        double torqueStrength = VStuffConfigs.server().reactionWheelMaxTorque.get();

        if (maxSpeed <= 0) return;

        double torqueMagnitude = (data.rotationSpeed / maxSpeed) * torqueStrength;

        Vector3d worldTorque = new Vector3d(
                data.facing.x(),
                data.facing.y(),
                data.facing.z()
        ).mul(torqueMagnitude);

        Vector3d shipTorque =
                ship.getTransform().getWorldToShip()
                        .transformDirection(worldTorque, new Vector3d());

        ship.applyInvariantTorque(shipTorque);
    }


    private void applyStabilizationTorque(PhysShipImpl ship) {

    }
}
