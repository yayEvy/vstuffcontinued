package dev.flarelog.vstuff.content.physics.ships.reactionwheel;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.jetbrains.annotations.NotNull;
import org.valkyrienskies.core.api.ships.PhysShip;
import org.valkyrienskies.core.api.ships.ShipPhysicsListener;
import org.valkyrienskies.core.api.world.PhysLevel;
import org.valkyrienskies.core.impl.game.ships.PhysShipImpl;
import net.minecraft.core.BlockPos;

public final class ReactionWheelAttachment implements ShipPhysicsListener {
    public Map<Long, ReactionWheelForceApplier> appliersMapping = new ConcurrentHashMap<>();
    ReactionWheelAttachment() {}

    @Override
    public void physTick(@NotNull PhysShip physicShip, @NotNull PhysLevel physLevel) {
        PhysShipImpl ship = (PhysShipImpl) physicShip;
        appliersMapping.forEach((pos, applier) -> {
            applier.applyForces(BlockPos.of(pos), ship);
        });
    }

    public void addApplier(BlockPos pos, ReactionWheelForceApplier applier) {
        appliersMapping.put(pos.asLong(), applier);
    }

    public void removeApplier(BlockPos pos) {
        appliersMapping.remove(pos.asLong());
    }
}