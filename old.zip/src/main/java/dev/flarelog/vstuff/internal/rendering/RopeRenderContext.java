package dev.flarelog.vstuff.internal.rendering;

import net.minecraft.world.level.Level;
import org.joml.Vector3d;

public record RopeRenderContext(
        Vector3d startRelative,
        Vector3d endRelative,
        Vector3d prevStartRelative,
        Vector3d prevEndRelative,
        double actualLength,
        float partialTick,
        Level level,
        net.minecraft.core.BlockPos startBlockPos,
        net.minecraft.core.BlockPos endBlockPos
) {} // record class of doom and despair
